Este es el código principal para el funcionamiento de la ÚLTIMA
versión del robot móvil, donde se incorporan 2 arreglos de sensores
para el seguimiento de linea en ambos sentidos (hacia adelante y atras).
Los arreglos son conectados a través del multipexor analógico 74HC4067.


Falta por implementar
* Máquina de estados
* Rutina de autocalibración
* Supervición de variables de interes (UDP)
* Comunicación V2V utilizando ESPNOW